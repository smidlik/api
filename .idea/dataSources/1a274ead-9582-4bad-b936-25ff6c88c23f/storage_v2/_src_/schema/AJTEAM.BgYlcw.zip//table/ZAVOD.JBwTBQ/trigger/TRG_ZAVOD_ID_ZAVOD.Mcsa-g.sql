create trigger TRG_ZAVOD_ID_ZAVOD
  before insert
  on ZAVOD
  for each row
BEGIN 
		SELECT "SEQ_ZAVOD_ID_ZAVOD".NEXTVAL 
		INTO :NEW."ID_ZAVOD" 
		FROM DUAL; 
	END;
/

