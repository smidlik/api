create trigger TRG_TEAM_ID_TEAM
  before insert
  on TEAM
  for each row
BEGIN 
		SELECT "SEQ_TEAM_ID_TEAM".NEXTVAL 
		INTO :NEW."ID_TEAM" 
		FROM DUAL; 
	END;
/

