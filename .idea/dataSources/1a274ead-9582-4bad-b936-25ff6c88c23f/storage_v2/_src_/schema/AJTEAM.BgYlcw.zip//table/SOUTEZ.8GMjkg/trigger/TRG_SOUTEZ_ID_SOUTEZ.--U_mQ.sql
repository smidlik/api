create trigger TRG_SOUTEZ_ID_SOUTEZ
  before insert
  on SOUTEZ
  for each row
BEGIN 
		SELECT "SEQ_SOUTEZ_ID_SOUTEZ".NEXTVAL 
		INTO :NEW."ID_SOUTEZ" 
		FROM DUAL; 
	END;
/

