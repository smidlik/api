create trigger TRG_LIGA_ID_LIGA
  before insert
  on LIGA
  for each row
BEGIN 
		SELECT "SEQ_LIGA_ID_LIGA".NEXTVAL 
		INTO :NEW."ID_LIGA" 
		FROM DUAL; 
	END;
/

